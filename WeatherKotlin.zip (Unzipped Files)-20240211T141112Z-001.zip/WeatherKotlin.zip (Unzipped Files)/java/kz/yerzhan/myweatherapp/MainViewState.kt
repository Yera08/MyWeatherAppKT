package kz.yerzhan.myweatherapp

import kz.yerzhan.myweatherapp.api.WeatherResponse

sealed interface MainViewState

data object loading : MainViewState
data class Data(val weatherResponse: WeatherResponse) : MainViewState
data object Error : MainViewState
